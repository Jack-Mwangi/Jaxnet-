"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { MotionWrapper } from "@/components/animation/motion-wrapper";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
        ? "bg-black/80 backdrop-blur-md py-2 gothic-shadow"
        : "bg-transparent py-4"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <MotionWrapper animation="fadeRight" delay={0.1}>
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold gothic-glow">
                <span className="accent-purple">JAX</span> Net Solutions
              </span>
            </Link>
          </MotionWrapper>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <MotionWrapper animation="fadeIn" delay={0.2}>
              <Link href="#features" className="text-white hover:text-purple-400 transition-colors">
                Features
              </Link>
            </MotionWrapper>
            <MotionWrapper animation="fadeIn" delay={0.3}>
              <Link href="#testimonials" className="text-white hover:text-purple-400 transition-colors">
                Testimonials
              </Link>
            </MotionWrapper>
            <MotionWrapper animation="fadeIn" delay={0.4}>
              <Link href="#contact" className="text-white hover:text-purple-400 transition-colors">
                Contact
              </Link>
            </MotionWrapper>
            <MotionWrapper animation="fadeIn" delay={0.5}>
              <Link href="https://websy.io" target="_blank" rel="noopener noreferrer" className="text-white hover:text-purple-400 transition-colors">
                Websy
              </Link>
            </MotionWrapper>
            <MotionWrapper animation="fadeIn" delay={0.6}>
              <Button
                asChild
                className="bg-purple-700 hover:bg-purple-800 text-white transition-colors"
              >
                <Link href="#contact">
                  Get Started
                </Link>
              </Button>
            </MotionWrapper>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 gothic-gradient gothic-border rounded-lg gothic-shadow">
            <nav className="flex flex-col space-y-4 p-4">
              <Link
                href="#features"
                className="text-white hover:text-purple-400 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Features
              </Link>
              <Link
                href="#testimonials"
                className="text-white hover:text-purple-400 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Testimonials
              </Link>
              <Link
                href="#contact"
                className="text-white hover:text-purple-400 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Contact
              </Link>
              <Link
                href="https://websy.io"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-purple-400 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                Websy
              </Link>
              <Button
                asChild
                className="bg-purple-700 hover:bg-purple-800 text-white w-full transition-colors"
              >
                <Link
                  href="#contact"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Get Started
                </Link>
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
