"use client";

import Link from "next/link";
import { MotionWrapper } from "@/components/animation/motion-wrapper";
import { Facebook, Twitter, Instagram, Linkedin, Heart } from "lucide-react";

export default function Footer() {
  return (
    <footer className="py-10 border-t border-gray-800 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <MotionWrapper animation="fadeUp" delay={0.1} className="col-span-1 md:col-span-1">
            <Link href="/" className="inline-block mb-4">
              <span className="text-2xl font-bold gothic-glow">
                <span className="accent-purple">JAX</span> Net Solutions
              </span>
            </Link>
            <p className="text-gray-400 mb-4">
              We create stunning websites that drive results and help businesses succeed in the digital world.
            </p>
            <div className="flex space-x-4">
              <Link href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Facebook size={20} />
              </Link>
              <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Twitter size={20} />
              </Link>
              <Link href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Instagram size={20} />
              </Link>
              <Link href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors">
                <Linkedin size={20} />
              </Link>
            </div>
          </MotionWrapper>

          <MotionWrapper animation="fadeUp" delay={0.2}>
            <h3 className="font-semibold text-white mb-4">Product</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#features" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Features
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Case Studies
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Documentation
                </Link>
              </li>
            </ul>
          </MotionWrapper>

          <MotionWrapper animation="fadeUp" delay={0.3}>
            <h3 className="font-semibold text-white mb-4">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="https://websy.io" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Websy
                </Link>
              </li>
            </ul>
          </MotionWrapper>

          <MotionWrapper animation="fadeUp" delay={0.4}>
            <h3 className="font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </MotionWrapper>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-500">
          <MotionWrapper animation="fadeUp" delay={0.5}>
            <p className="mb-2">© {new Date().getFullYear()} JAX Net Solutions. All rights reserved.</p>
            <p className="flex items-center justify-center gap-1">
              Designed and built with <Heart className="h-4 w-4 text-purple-500" fill="currentColor" /> by JAX Net Solutions team
            </p>
          </MotionWrapper>
        </div>
      </div>
    </footer>
  );
}
