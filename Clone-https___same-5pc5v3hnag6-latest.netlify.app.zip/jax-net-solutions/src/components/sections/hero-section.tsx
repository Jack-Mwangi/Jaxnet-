"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { MotionWrapper } from "@/components/animation/motion-wrapper";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center py-20 pt-32 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-black/60" />

        {/* Animated background circles */}
        <motion.div
          className="absolute top-1/4 right-1/4 w-64 h-64 rounded-full bg-purple-900/20 blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.3, 0.2]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />

        <motion.div
          className="absolute bottom-1/3 left-1/3 w-80 h-80 rounded-full bg-indigo-900/20 blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.3, 0.2, 0.3]
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <MotionWrapper animation="fadeUp" delay={0.2}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 gothic-glow">
                Create <span className="accent-purple">Stunning</span>
                <br />Websites That <span className="accent-purple">Convert</span>
              </h1>
            </MotionWrapper>

            <MotionWrapper animation="fadeUp" delay={0.4}>
              <p className="text-lg text-gray-300 mb-8">
                Build beautiful, responsive websites that drive results. Our modern gothic designs
                are optimized for user engagement and conversions.
              </p>
            </MotionWrapper>

            <MotionWrapper animation="fadeUp" delay={0.6}>
              <div className="flex flex-wrap gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-purple-700 hover:bg-purple-800 text-white px-8"
                >
                  <Link href="#contact">
                    Get Started
                  </Link>
                </Button>

                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-purple-600 text-white hover:bg-purple-900/20"
                >
                  <Link href="#features">
                    Learn More
                  </Link>
                </Button>
              </div>
            </MotionWrapper>
          </div>

          <div className="relative">
            <MotionWrapper animation="fadeLeft" delay={0.5}>
              <div className="relative gothic-shadow rounded-lg overflow-hidden">
                <div className="absolute inset-0 gothic-gradient opacity-80 z-10"></div>
                <img
                  src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80"
                  alt="Developer working on code"
                  className="w-full h-auto rounded-lg relative z-0"
                />

                <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center z-20">
                  <div className="text-center">
                    <p className="text-xl md:text-2xl font-bold text-white gothic-glow mb-4">
                      Elevate Your Digital Presence
                    </p>
                    <div className="flex justify-center gap-2">
                      <span className="flex h-3 w-3 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-purple-500"></span>
                      </span>
                      <span className="text-gray-200">Live Development</span>
                    </div>
                  </div>
                </div>
              </div>
            </MotionWrapper>
          </div>
        </div>
      </div>
    </section>
  );
}
