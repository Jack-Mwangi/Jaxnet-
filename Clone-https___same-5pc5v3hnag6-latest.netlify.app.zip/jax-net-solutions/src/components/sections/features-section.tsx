"use client";

import { MotionWrapper } from "@/components/animation/motion-wrapper";
import { Card } from "@/components/ui/card";
import { LaptopIcon, PaintbrushIcon, ZapIcon, ShieldIcon, UserIcon, SearchIcon } from "lucide-react";

const features = [
  {
    icon: <LaptopIcon className="h-8 w-8" />,
    title: "Responsive Design",
    description: "Our websites look stunning on any device, from desktop to mobile."
  },
  {
    icon: <PaintbrushIcon className="h-8 w-8" />,
    title: "Gothic Aesthetics",
    description: "Dark, elegant designs that align with your brand identity while making a bold statement."
  },
  {
    icon: <ZapIcon className="h-8 w-8" />,
    title: "Performance Optimized",
    description: "Lightning-fast load times for an exceptional user experience."
  },
  {
    icon: <ShieldIcon className="h-8 w-8" />,
    title: "Secure Framework",
    description: "Built-in security features to protect your website and users."
  },
  {
    icon: <UserIcon className="h-8 w-8" />,
    title: "User-Friendly CMS",
    description: "Easy content management systems that anyone can use."
  },
  {
    icon: <SearchIcon className="h-8 w-8" />,
    title: "SEO Ready",
    description: "Optimized code that helps your site rank higher in search results."
  }
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <MotionWrapper animation="fadeUp" delay={0.1}>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 gothic-glow">
              Powerful <span className="accent-purple">Features</span> for Your Success
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our websites combine beautiful gothic design with powerful functionality to drive results.
            </p>
          </div>
        </MotionWrapper>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <MotionWrapper
              key={index}
              animation="fadeUp"
              delay={0.2 + index * 0.1}
              className="h-full"
            >
              <Card className="p-6 h-full gothic-gradient gothic-border gothic-shadow hover:shadow-purple-900/20 hover:border-purple-800/50 transition-all duration-300">
                <div className="flex flex-col h-full">
                  <div className="p-2 rounded-full bg-purple-900/20 w-fit mb-4">
                    <div className="text-purple-400">
                      {feature.icon}
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2 accent-purple">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </Card>
            </MotionWrapper>
          ))}
        </div>
      </div>
    </section>
  );
}
