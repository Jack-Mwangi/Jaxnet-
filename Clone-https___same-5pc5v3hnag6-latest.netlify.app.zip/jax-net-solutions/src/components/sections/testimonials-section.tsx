"use client";

import { useState } from "react";
import { MotionWrapper } from "@/components/animation/motion-wrapper";
import { Card } from "@/components/ui/card";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Marketing Director, TechCorp",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    text: "Working with JAX Net Solutions was a game-changer for our business. Our new website has increased conversions by 45% in just three months. The dark, gothic design is stunning and the functionality is exactly what we needed."
  },
  {
    name: "David Chen",
    role: "CEO, Startup Innovations",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    text: "We needed a website that could scale with our rapid growth. JAX Net Solutions delivered a beautiful, responsive design that our customers love. Their attention to detail and technical expertise is unmatched."
  },
  {
    name: "Michelle Thompson",
    role: "Owner, Boutique Retail",
    image: "https://randomuser.me/api/portraits/women/28.jpg",
    text: "Our e-commerce site needed a complete overhaul. JAX Net Solutions understood our vision perfectly and created a website that perfectly represents our brand. Sales have increased by 70% since launch!"
  },
  {
    name: "James Wilson",
    role: "CTO, Enterprise Solutions",
    image: "https://randomuser.me/api/portraits/men/45.jpg",
    text: "The gothic aesthetic of our new site has been a huge hit with our audience. JAX Net Solutions truly understood our unique requirements and delivered a high-performance solution that exceeded our expectations."
  }
];

export default function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleNext = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const handlePrev = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="py-20 relative overflow-hidden">
      {/* Background gradients */}
      <div className="absolute top-1/3 left-0 w-full h-2/3 bg-purple-900/10 blur-3xl -z-10 transform -rotate-12"></div>

      <div className="container mx-auto px-4">
        <MotionWrapper animation="fadeUp" delay={0.1}>
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 gothic-glow">
              What Our <span className="accent-purple">Clients</span> Say
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Don't just take our word for it. See what our clients have to say about their experience.
            </p>
          </div>
        </MotionWrapper>

        <div className="hidden md:block">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {testimonials.map((testimonial, index) => (
              <MotionWrapper
                key={index}
                animation="fadeUp"
                delay={0.2 + index * 0.1}
                className="h-full"
              >
                <Card className="p-6 h-full gothic-gradient gothic-border gothic-shadow hover:shadow-purple-900/20 transition-all duration-300">
                  <div className="flex flex-col h-full">
                    <div className="flex items-center space-x-1 text-yellow-500 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={16} fill="currentColor" />
                      ))}
                    </div>
                    <p className="text-gray-300 mb-4 flex-grow">"{testimonial.text}"</p>
                    <div className="flex items-center mt-4">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full mr-4 border-2 border-purple-600"
                      />
                      <div>
                        <p className="font-medium accent-purple">{testimonial.name}</p>
                        <p className="text-sm text-gray-400">{testimonial.role}</p>
                      </div>
                    </div>
                  </div>
                </Card>
              </MotionWrapper>
            ))}
          </div>
        </div>

        {/* Mobile slider */}
        <div className="md:hidden">
          <MotionWrapper
            animation="fadeUp"
            delay={0.2}
            key={activeIndex}
            className="h-full"
          >
            <Card className="p-6 h-full gothic-gradient gothic-border gothic-shadow">
              <div className="flex flex-col h-full">
                <div className="flex items-center space-x-1 text-yellow-500 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill="currentColor" />
                  ))}
                </div>
                <p className="text-gray-300 mb-4 flex-grow">"{testimonials[activeIndex].text}"</p>
                <div className="flex items-center mt-4">
                  <img
                    src={testimonials[activeIndex].image}
                    alt={testimonials[activeIndex].name}
                    className="w-12 h-12 rounded-full mr-4 border-2 border-purple-600"
                  />
                  <div>
                    <p className="font-medium accent-purple">{testimonials[activeIndex].name}</p>
                    <p className="text-sm text-gray-400">{testimonials[activeIndex].role}</p>
                  </div>
                </div>

                <div className="flex justify-between mt-6">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handlePrev}
                    className="border-purple-600 text-purple-400 hover:bg-purple-900/20"
                  >
                    <ChevronLeft size={18} />
                  </Button>
                  <div className="flex space-x-2">
                    {testimonials.map((_, index) => (
                      <div
                        key={index}
                        className={`w-2 h-2 rounded-full ${activeIndex === index ? 'bg-purple-500' : 'bg-gray-600'}`}
                      ></div>
                    ))}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleNext}
                    className="border-purple-600 text-purple-400 hover:bg-purple-900/20"
                  >
                    <ChevronRight size={18} />
                  </Button>
                </div>
              </div>
            </Card>
          </MotionWrapper>
        </div>
      </div>
    </section>
  );
}
