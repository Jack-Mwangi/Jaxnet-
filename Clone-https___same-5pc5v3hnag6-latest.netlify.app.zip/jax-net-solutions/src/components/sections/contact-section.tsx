"use client";

import { useState } from "react";
import { MotionWrapper } from "@/components/animation/motion-wrapper";
import { Card } from "@/components/ui/card";
import { Form } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Mail, Phone } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().optional(),
  message: z.string().min(10, { message: "Message must be at least 10 characters." }),
});

export default function ContactSection() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true);

    // This is a simulated form submission with redirection to email
    setTimeout(() => {
      // In a real implementation, you'd submit to your backend
      // or use a form service like Formspree

      // Redirect to email client
      const subject = `Website Inquiry from ${values.name}`;
      const body = `Name: ${values.name}\nEmail: ${values.email}\nPhone: ${values.phone || 'Not provided'}\n\nMessage: ${values.message}`;
      const mailtoLink = `mailto:mwangijackson140@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

      window.location.href = mailtoLink;

      setIsSubmitting(false);
      setIsSubmitted(true);
      form.reset();
    }, 1000);
  }

  return (
    <section id="contact" className="py-20 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute bottom-0 right-0 w-full h-full bg-purple-900/5 blur-3xl -z-10"></div>

      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-start">
          <div>
            <MotionWrapper animation="fadeRight" delay={0.2}>
              <h2 className="text-3xl md:text-4xl font-bold mb-4 gothic-glow">
                Let's Build Your <span className="accent-purple">Dream</span> Website
              </h2>
              <p className="text-gray-400 mb-8">
                Ready to take your online presence to the next level? Get in touch with us today
                and let's discuss how we can help you achieve your goals.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-purple-900/20 w-fit mr-4">
                    <Mail className="h-5 w-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Email</p>
                    <p className="accent-purple">mwangijackson140@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-purple-900/20 w-fit mr-4">
                    <Phone className="h-5 w-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Phone</p>
                    <p className="text-white">(123) 456-7890</p>
                  </div>
                </div>
              </div>
            </MotionWrapper>
          </div>

          <MotionWrapper animation="fadeLeft" delay={0.4}>
            <Card className="p-6 gothic-gradient gothic-border gothic-shadow">
              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2 gothic-glow">Contact Us</h3>
                <p className="text-gray-400 text-sm">
                  Fill out the form below and we'll get back to you soon.
                </p>
              </div>

              {isSubmitted ? (
                <div className="text-center py-8">
                  <div className="mb-4 mx-auto w-16 h-16 rounded-full bg-purple-900/20 flex items-center justify-center">
                    <svg className="w-8 h-8 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  <h4 className="text-xl font-semibold gothic-glow mb-2">Thank You!</h4>
                  <p className="text-gray-400">
                    Your message has been sent. We'll be in touch with you shortly.
                  </p>
                  <Button
                    className="mt-6 bg-purple-700 hover:bg-purple-800 text-white"
                    onClick={() => setIsSubmitted(false)}
                  >
                    Send Another Message
                  </Button>
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm text-gray-300">Name</label>
                      <Input
                        id="name"
                        placeholder="Your name"
                        {...form.register("name")}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                      {form.formState.errors.name && (
                        <p className="text-red-500 text-xs mt-1">{form.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm text-gray-300">Email</label>
                      <Input
                        id="email"
                        placeholder="you@example.com"
                        {...form.register("email")}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                      {form.formState.errors.email && (
                        <p className="text-red-500 text-xs mt-1">{form.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm text-gray-300">Phone (Optional)</label>
                      <Input
                        id="phone"
                        placeholder="(123) 456-7890"
                        {...form.register("phone")}
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm text-gray-300">Message</label>
                      <Textarea
                        id="message"
                        placeholder="Tell us about your project..."
                        rows={4}
                        {...form.register("message")}
                        className="bg-gray-800/50 border-gray-700 text-white resize-none"
                      />
                      {form.formState.errors.message && (
                        <p className="text-red-500 text-xs mt-1">{form.formState.errors.message.message}</p>
                      )}
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-purple-700 hover:bg-purple-800 text-white"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Submitting..." : "Submit"}
                    </Button>
                  </form>
                </Form>
              )}
            </Card>
          </MotionWrapper>
        </div>
      </div>
    </section>
  );
}
